import os
import sqlite3
import csv
import io
from datetime import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, redirect, url_for, 
    flash, session, g, jsonify, send_file
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-super-secret-key-in-production-2026")
app.config["DATABASE"] = os.path.join(os.path.dirname(__file__), "recharge.db")
app.config["UPLOAD_FOLDER"] = os.path.join(os.path.dirname(__file__), "uploads")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5MB

# Default admin (change password after first login!)
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD_HASH = generate_password_hash(os.environ.get("ADMIN_PASSWORD", "admin123"))

NETWORKS = ["MTN", "Airtel", "Glo", "9mobile"]
PRODUCT_TYPES = ["Airtime", "Data"]

# ------------------- Database helpers -------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            network TEXT NOT NULL,
            product_type TEXT NOT NULL,
            name TEXT NOT NULL,
            amount REAL NOT NULL,
            price REAL NOT NULL,
            description TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS pins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            pin_code TEXT NOT NULL UNIQUE,
            status TEXT DEFAULT 'available',  -- available | sold | reserved
            order_id INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            sold_at TEXT,
            FOREIGN KEY (product_id) REFERENCES products(id),
            FOREIGN KEY (order_id) REFERENCES orders(id)
        );

        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_ref TEXT UNIQUE NOT NULL,
            customer_name TEXT NOT NULL,
            customer_phone TEXT NOT NULL,
            customer_email TEXT,
            product_id INTEGER NOT NULL,
            pin_id INTEGER,
            amount_paid REAL NOT NULL,
            payment_method TEXT,
            payment_status TEXT DEFAULT 'pending',  -- pending | paid | failed
            payment_ref TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            paid_at TEXT,
            FOREIGN KEY (product_id) REFERENCES products(id)
        );

        CREATE TABLE IF NOT EXISTS admin_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        );
    """)
    # Seed default admin if not exists
    cur = db.execute("SELECT id FROM admin_users WHERE username = ?", (ADMIN_USERNAME,))
    if not cur.fetchone():
        db.execute(
            "INSERT INTO admin_users (username, password_hash) VALUES (?, ?)",
            (ADMIN_USERNAME, ADMIN_PASSWORD_HASH)
        )
    db.commit()

# ------------------- Auth helpers -------------------
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("admin_logged_in"):
            flash("Please login to access admin area.", "warning")
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return decorated

# ------------------- Utility -------------------
def generate_order_ref():
    return f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}-{os.urandom(3).hex().upper()}"

def get_stock(product_id):
    db = get_db()
    cur = db.execute(
        "SELECT COUNT(*) as cnt FROM pins WHERE product_id = ? AND status = 'available'",
        (product_id,)
    )
    return cur.fetchone()["cnt"]

# ------------------- Public Routes -------------------
@app.route("/")
def index():
    db = get_db()
    products = db.execute("""
        SELECT p.*, 
               (SELECT COUNT(*) FROM pins WHERE product_id = p.id AND status = 'available') as stock
        FROM products p
        WHERE p.is_active = 1
        ORDER BY p.network, p.product_type, p.amount
    """).fetchall()

    # Group by network
    grouped = {}
    for p in products:
        net = p["network"]
        if net not in grouped:
            grouped[net] = {"Airtime": [], "Data": []}
        grouped[net][p["product_type"]].append(p)

    return render_template("index.html", grouped=grouped, networks=NETWORKS)

@app.route("/product/<int:product_id>")
def product_detail(product_id):
    db = get_db()
    product = db.execute("SELECT * FROM products WHERE id = ? AND is_active = 1", (product_id,)).fetchone()
    if not product:
        flash("Product not found.", "danger")
        return redirect(url_for("index"))
    stock = get_stock(product_id)
    return render_template("product.html", product=product, stock=stock)

@app.route("/checkout/<int:product_id>", methods=["GET", "POST"])
def checkout(product_id):
    db = get_db()
    product = db.execute("SELECT * FROM products WHERE id = ? AND is_active = 1", (product_id,)).fetchone()
    if not product:
        flash("Product not found.", "danger")
        return redirect(url_for("index"))

    stock = get_stock(product_id)
    if stock < 1:
        flash("Sorry, this product is currently out of stock.", "warning")
        return redirect(url_for("product_detail", product_id=product_id))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        payment_method = request.form.get("payment_method", "test")

        if not name or not phone:
            flash("Name and phone number are required.", "danger")
            return render_template("checkout.html", product=product, stock=stock)

        # Create order
        order_ref = generate_order_ref()
        cur = db.execute("""
            INSERT INTO orders (order_ref, customer_name, customer_phone, customer_email, 
                                product_id, amount_paid, payment_method, payment_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
        """, (order_ref, name, phone, email or None, product_id, product["price"], payment_method))
        order_id = cur.lastrowid
        db.commit()

        # For demo / test mode → auto complete
        if payment_method == "test":
            return redirect(url_for("complete_payment", order_ref=order_ref, method="test"))

        # In production you would redirect to Paystack / Flutterwave here
        # For now we show a simulation page
        return render_template("payment_simulate.html", 
                               order_ref=order_ref, 
                               product=product, 
                               amount=product["price"],
                               payment_method=payment_method)

    return render_template("checkout.html", product=product, stock=stock)

@app.route("/complete-payment/<order_ref>")
def complete_payment(order_ref):
    """Called after successful payment (or test mode)"""
    method = request.args.get("method", "test")
    db = get_db()

    order = db.execute("SELECT * FROM orders WHERE order_ref = ?", (order_ref,)).fetchone()
    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for("index"))

    if order["payment_status"] == "paid":
        # Already paid – show the PIN again
        pin = db.execute("SELECT * FROM pins WHERE order_id = ?", (order["id"],)).fetchone()
        product = db.execute("SELECT * FROM products WHERE id = ?", (order["product_id"],)).fetchone()
        return render_template("success.html", order=order, pin=pin, product=product)

    # Reserve and assign a PIN
    pin = db.execute("""
        SELECT * FROM pins 
        WHERE product_id = ? AND status = 'available' 
        LIMIT 1
    """, (order["product_id"],)).fetchone()

    if not pin:
        flash("Sorry, stock ran out while processing. Please contact support.", "danger")
        return redirect(url_for("index"))

    # Mark pin as sold and update order
    now = datetime.now().isoformat()
    db.execute("""
        UPDATE pins SET status = 'sold', order_id = ?, sold_at = ? WHERE id = ?
    """, (order["id"], now, pin["id"]))
    db.execute("""
        UPDATE orders SET payment_status = 'paid', paid_at = ?, pin_id = ?, payment_ref = ?
        WHERE id = ?
    """, (now, pin["id"], f"{method.upper()}-{os.urandom(4).hex()}", order["id"]))
    db.commit()

    # Refresh
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order["id"],)).fetchone()
    product = db.execute("SELECT * FROM products WHERE id = ?", (order["product_id"],)).fetchone()
    pin = db.execute("SELECT * FROM pins WHERE id = ?", (pin["id"],)).fetchone()

    return render_template("success.html", order=order, pin=pin, product=product)

@app.route("/order/<order_ref>")
def view_order(order_ref):
    db = get_db()
    order = db.execute("SELECT * FROM orders WHERE order_ref = ?", (order_ref,)).fetchone()
    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for("index"))
    product = db.execute("SELECT * FROM products WHERE id = ?", (order["product_id"],)).fetchone()
    pin = None
    if order["pin_id"]:
        pin = db.execute("SELECT * FROM pins WHERE id = ?", (order["pin_id"],)).fetchone()
    return render_template("success.html", order=order, pin=pin, product=product)

# ------------------- Admin Routes -------------------
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin_dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        db = get_db()
        user = db.execute("SELECT * FROM admin_users WHERE username = ?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["admin_logged_in"] = True
            session["admin_username"] = username
            flash("Welcome back!", "success")
            return redirect(url_for("admin_dashboard"))
        flash("Invalid username or password.", "danger")

    return render_template("admin/login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("admin_login"))

@app.route("/admin")
@login_required
def admin_dashboard():
    db = get_db()
    stats = {
        "total_products": db.execute("SELECT COUNT(*) as c FROM products").fetchone()["c"],
        "available_pins": db.execute("SELECT COUNT(*) as c FROM pins WHERE status = 'available'").fetchone()["c"],
        "sold_pins": db.execute("SELECT COUNT(*) as c FROM pins WHERE status = 'sold'").fetchone()["c"],
        "total_orders": db.execute("SELECT COUNT(*) as c FROM orders").fetchone()["c"],
        "paid_orders": db.execute("SELECT COUNT(*) as c FROM orders WHERE payment_status = 'paid'").fetchone()["c"],
        "revenue": db.execute("SELECT COALESCE(SUM(amount_paid), 0) as s FROM orders WHERE payment_status = 'paid'").fetchone()["s"],
    }
    recent_orders = db.execute("""
        SELECT o.*, p.name as product_name, p.network 
        FROM orders o 
        JOIN products p ON o.product_id = p.id 
        ORDER BY o.created_at DESC LIMIT 10
    """).fetchall()
    return render_template("admin/dashboard.html", stats=stats, recent_orders=recent_orders)

@app.route("/admin/products")
@login_required
def admin_products():
    db = get_db()
    products = db.execute("""
        SELECT p.*, 
               (SELECT COUNT(*) FROM pins WHERE product_id = p.id AND status = 'available') as stock,
               (SELECT COUNT(*) FROM pins WHERE product_id = p.id AND status = 'sold') as sold
        FROM products p
        ORDER BY p.network, p.product_type, p.amount
    """).fetchall()
    return render_template("admin/products.html", products=products, networks=NETWORKS, types=PRODUCT_TYPES)

@app.route("/admin/products/add", methods=["GET", "POST"])
@login_required
def admin_add_product():
    if request.method == "POST":
        network = request.form.get("network")
        product_type = request.form.get("product_type")
        name = request.form.get("name", "").strip()
        amount = request.form.get("amount", type=float)
        price = request.form.get("price", type=float)
        description = request.form.get("description", "").strip()

        if not all([network, product_type, name, amount is not None, price is not None]):
            flash("All required fields must be filled.", "danger")
            return redirect(url_for("admin_add_product"))

        db = get_db()
        db.execute("""
            INSERT INTO products (network, product_type, name, amount, price, description)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (network, product_type, name, amount, price, description or None))
        db.commit()
        flash(f"Product '{name}' added successfully!", "success")
        return redirect(url_for("admin_products"))

    return render_template("admin/add_product.html", networks=NETWORKS, types=PRODUCT_TYPES)

@app.route("/admin/products/<int:product_id>/toggle", methods=["POST"])
@login_required
def admin_toggle_product(product_id):
    db = get_db()
    prod = db.execute("SELECT is_active FROM products WHERE id = ?", (product_id,)).fetchone()
    if prod:
        new_status = 0 if prod["is_active"] else 1
        db.execute("UPDATE products SET is_active = ? WHERE id = ?", (new_status, product_id))
        db.commit()
        flash("Product status updated.", "success")
    return redirect(url_for("admin_products"))

@app.route("/admin/pins")
@login_required
def admin_pins():
    db = get_db()
    products = db.execute("SELECT id, network, product_type, name, amount FROM products ORDER BY network, amount").fetchall()
    # Stock summary
    stock = db.execute("""
        SELECT p.id, p.network, p.name, p.amount,
               SUM(CASE WHEN pins.status = 'available' THEN 1 ELSE 0 END) as available,
               SUM(CASE WHEN pins.status = 'sold' THEN 1 ELSE 0 END) as sold
        FROM products p
        LEFT JOIN pins ON pins.product_id = p.id
        GROUP BY p.id
        ORDER BY p.network, p.amount
    """).fetchall()
    return render_template("admin/pins.html", products=products, stock=stock)

@app.route("/admin/pins/upload", methods=["GET", "POST"])
@login_required
def admin_upload_pins():
    db = get_db()
    products = db.execute("SELECT id, network, product_type, name, amount FROM products ORDER BY network, amount").fetchall()

    if request.method == "POST":
        product_id = request.form.get("product_id", type=int)
        pin_text = request.form.get("pin_text", "").strip()
        file = request.files.get("pin_file")

        if not product_id:
            flash("Please select a product.", "danger")
            return redirect(url_for("admin_upload_pins"))

        pins_to_add = []

        # From textarea
        if pin_text:
            for line in pin_text.splitlines():
                code = line.strip()
                if code:
                    pins_to_add.append(code)

        # From CSV / text file
        if file and file.filename:
            try:
                content = file.read().decode("utf-8", errors="ignore")
                reader = csv.reader(io.StringIO(content))
                for row in reader:
                    if row:
                        code = row[0].strip()
                        if code and not code.lower().startswith("pin"):
                            pins_to_add.append(code)
            except Exception as e:
                flash(f"Error reading file: {e}", "danger")
                return redirect(url_for("admin_upload_pins"))

        if not pins_to_add:
            flash("No valid PINs found to upload.", "warning")
            return redirect(url_for("admin_upload_pins"))

        # Insert (ignore duplicates)
        added = 0
        skipped = 0
        for code in pins_to_add:
            try:
                db.execute(
                    "INSERT INTO pins (product_id, pin_code, status) VALUES (?, ?, 'available')",
                    (product_id, code)
                )
                added += 1
            except sqlite3.IntegrityError:
                skipped += 1
        db.commit()

        flash(f"Upload complete: {added} PINs added, {skipped} duplicates skipped.", "success")
        return redirect(url_for("admin_pins"))

    return render_template("admin/upload_pins.html", products=products)

@app.route("/admin/orders")
@login_required
def admin_orders():
    db = get_db()
    orders = db.execute("""
        SELECT o.*, p.name as product_name, p.network, p.product_type,
               pins.pin_code
        FROM orders o
        JOIN products p ON o.product_id = p.id
        LEFT JOIN pins ON o.pin_id = pins.id
        ORDER BY o.created_at DESC
        LIMIT 200
    """).fetchall()
    return render_template("admin/orders.html", orders=orders)

# ------------------- Init & Run -------------------
@app.cli.command("init-db")
def init_db_command():
    """Initialize the database."""
    init_db()
    print("Database initialized.")

if __name__ == "__main__":
    with app.app_context():
        init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
