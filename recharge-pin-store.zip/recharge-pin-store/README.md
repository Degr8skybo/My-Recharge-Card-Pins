# PinStore NG – Online Recharge PIN Store

Full web application for selling **MTN, Airtel, Glo & 9mobile** Airtime and Data PINs in Nigeria.

## Features

- Beautiful mobile-friendly storefront
- Airtime + Data products for all 4 networks
- Instant PIN delivery after payment
- Admin dashboard with:
  - Product management
  - Bulk PIN upload (paste or CSV)
  - Stock tracking
  - Order history & revenue stats
- Test mode + placeholders for **Paystack** and **Flutterwave**
- Easy to deploy on Render, Railway, or any VPS

## Default Admin Login

- **Username:** `admin`
- **Password:** `admin123`

**Change this immediately after first login!**

You can also set environment variables:
```
ADMIN_USERNAME=youradmin
ADMIN_PASSWORD=yourstrongpassword
SECRET_KEY=a-long-random-string
```

## Quick Start (Local)

```bash
cd recharge-pin-store
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

## How to Use

### 1. Login to Admin
Go to `/admin/login` → login with admin / admin123

### 2. Add Products
Admin → Products → Add Product  
Examples:
- Network: MTN, Type: Airtime, Name: ₦500 Airtime, Amount: 500, Price: 490
- Network: Airtel, Type: Data, Name: 1.5GB – 30 Days, Amount: 0, Price: 1000

### 3. Upload PINs
Admin → Upload PINs  
- Select the product
- Paste one PIN per line **or** upload a .csv / .txt file
- Duplicates are automatically skipped

### 4. Customers buy
Customers visit the homepage, choose a product, pay, and receive the PIN instantly.

## Payment Integration (Production)

Currently the app has:
- **Test Mode** → instant success (for testing)
- **Paystack / Flutterwave** buttons that go to a simulation page

To go live:

1. Create accounts on [Paystack](https://paystack.com) and/or [Flutterwave](https://flutterwave.com)
2. In `app.py` (checkout route), replace the simulation with real redirect to their payment page
3. Add a webhook endpoint to confirm payment and call the same logic as `/complete-payment/<order_ref>`

I can help you add the real Paystack/Flutterwave code when you are ready.

## Deploy on Render (Recommended – Free Tier)

1. Push this folder to a GitHub repository
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect the repo
4. Settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app:app`
   - **Environment:** Python 3
5. Add environment variables (optional but recommended):
   - `SECRET_KEY` = long random string
   - `ADMIN_USERNAME` / `ADMIN_PASSWORD`
6. Deploy

Your store will be live at `https://your-app.onrender.com`

## Deploy on Railway

1. Create project on [railway.app](https://railway.app)
2. Deploy from GitHub
3. Start command: `gunicorn app:app`
4. Add the same environment variables

## Important Security Notes

- Change the default admin password
- Set a strong `SECRET_KEY`
- In production, never expose the SQLite file publicly
- Consider moving to PostgreSQL later for higher traffic
- Always verify payment via webhook before releasing PINs (the current test flow is for demo only)

## File Structure

```
recharge-pin-store/
├── app.py                 # Main application
├── requirements.txt
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── product.html
│   ├── checkout.html
│   ├── payment_simulate.html
│   ├── success.html
│   └── admin/
│       ├── login.html
│       ├── dashboard.html
│       ├── products.html
│       ├── add_product.html
│       ├── pins.html
│       ├── upload_pins.html
│       └── orders.html
└── uploads/               # (optional for future file storage)
```

## Next Steps I can help with

- Real Paystack + Flutterwave integration
- Email / SMS delivery of PIN
- Customer order lookup by phone
- Multiple admin users
- PostgreSQL migration
- Custom domain + branding

Just ask!
